package com.example.CourseAPI.controller;


import com.example.CourseAPI.model.Course;
import com.example.CourseAPI.repo.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/course")
public class CourseController {

    @Autowired
    private CourseRepository courseRepository;

    @GetMapping("/{id}")
    public ResponseEntity<Course> get(@PathVariable("id") Long id){
        return courseRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Course> create(@RequestBody Course d ){
        Course savedDepartment = courseRepository.save(d);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedDepartment);
    }

    @GetMapping("/by-name/{name}")
    public ResponseEntity<Course> getByName(@PathVariable String courseName){
        return courseRepository.findByCourseNameIgnoreCase(courseName)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

//    @GetMapping("/{id}")
//    public ResponseEntity<List<Course>>getall() {
//        List<Course>response=courseRepository.getall();
//        return ResponseEntity.status(200).body(response);
//    }

}
