package com.example.StudentAPI.dto;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class CourseDto {

    Long id;
    String courseName;
    String courseDuration;
    Float courseFee;
}
