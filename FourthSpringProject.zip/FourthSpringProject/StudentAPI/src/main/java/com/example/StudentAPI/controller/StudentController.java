package com.example.StudentAPI.controller;


import com.example.StudentAPI.dto.StudentDto;
import com.example.StudentAPI.model.Student;
import com.example.StudentAPI.repo.StudentRepository;
import com.example.StudentAPI.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/student")
public class StudentController {


    @Autowired
    private StudentRepository studentRepository;

    private final StudentService studentService;

    public StudentController(StudentService studentService){
        this.studentService = studentService;
    }

    @GetMapping("/{id}")
    public StudentDto getProductViaFeign(@PathVariable Long id){
        return studentService.view(id);
    }

    @PostMapping
    public ResponseEntity<Student> create(@RequestBody Student student){
        Student savedStudent = studentRepository.save(student);
        return new ResponseEntity<Student>(savedStudent, HttpStatus.CREATED);
    }
}
