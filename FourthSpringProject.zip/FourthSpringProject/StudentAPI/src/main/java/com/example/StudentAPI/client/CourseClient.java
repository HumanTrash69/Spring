package com.example.StudentAPI.client;

import com.example.StudentAPI.dto.CourseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "CourseAPI",
        url = "http://localhost:8082",
        path = "/api/course")


public interface CourseClient {
    @GetMapping("/by-name/{name}")
    public CourseDto getByName(@PathVariable String name);

    @GetMapping("/{id}")
    public CourseDto getCourseById(@PathVariable Long id);
}

