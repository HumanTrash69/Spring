package com.example.StudentAPI.service;

import com.example.StudentAPI.client.CourseClient;
import com.example.StudentAPI.dto.CourseDto;
import com.example.StudentAPI.dto.StudentDto;
import com.example.StudentAPI.model.Student;
import com.example.StudentAPI.repo.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class StudentService {


    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private CourseClient courseClient;

    public StudentDto view(Long studentId){
        Student student =
                studentRepository.findById(studentId)
                        .orElseThrow(()->
                                new ResponseStatusException(HttpStatus.NOT_FOUND,
                                        "Student Id: " + studentId + " not found!"));
        //This is  a microservice call
        CourseDto course = courseClient.getCourseById(student.getCourse());

        return new StudentDto(
                student.getId(), student.getName(), student.getEmail(), course);

    }
}
