package com.example.departmentAPI.controller;

import com.example.departmentAPI.model.Department;
import com.example.departmentAPI.repo.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/department")
public class DepartmentController {

    @Autowired
    private DepartmentRepository departmentRepository;

    @GetMapping("/{id}")
    public ResponseEntity<Department> get(@PathVariable ("id") Long id){
        return departmentRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Department> create(@RequestBody Department d ){
        Department savedDepartment = departmentRepository.save(d);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedDepartment);
    }

    @GetMapping("/by-name/{name}")
    public ResponseEntity<Department> getByName(@PathVariable String name){
        return departmentRepository.findByNameIgnoreCase(name)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }



//    @GetMapping("/{id}")
//    public ResponseEntity<List<Department>>getall() {
//        List<Department>response=departmentRepository.getall();
//        return ResponseEntity.status(200).body(response);
//    }
}
