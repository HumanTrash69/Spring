package com.example.productAPI.client;

import com.example.productAPI.dto.DepartmentDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "DepartmentAPI",
        url = "http://localhost:8082",
        path = "/api/department")


public interface DepartmentClient {
    @GetMapping ("/by-name/{name}")
    public DepartmentDto getByName(@PathVariable String name);

    @GetMapping("/{id}")
    public DepartmentDto getDepartmentById(@PathVariable("id") Long id);

}
