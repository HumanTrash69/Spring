package com.example.productAPI.controller;

import com.example.productAPI.dto.ProductResponseDto;
import com.example.productAPI.model.Product;
import com.example.productAPI.repo.ProductRepository;
import com.example.productAPI.service.ProductReadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/product")
public class ProductController {
    @Autowired
    private ProductRepository productRepository;

    private final ProductReadService productReadService;

    public ProductController(ProductReadService productReadService){
        this.productReadService = productReadService;
    }

    @GetMapping("/{id}")
    public ProductResponseDto getProductViaFeign(@PathVariable Long id){
        return productReadService.view(id);
    }

    @PostMapping
    public ResponseEntity<Product> create(@RequestBody Product product){
        Product savedProduct = productRepository.save(product);
        return new ResponseEntity<Product>(savedProduct, HttpStatus.CREATED);
    }
}
