package com.example.productAPI.service;

import com.example.productAPI.client.DepartmentClient;
import com.example.productAPI.dto.DepartmentDto;
import com.example.productAPI.dto.ProductResponseDto;
import com.example.productAPI.model.Product;
import com.example.productAPI.repo.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class ProductReadService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private DepartmentClient departmentClient;

    public ProductResponseDto view(Long productId){
        Product product =
                productRepository.findById(productId)
                        .orElseThrow(()->
                                new ResponseStatusException(HttpStatus.NOT_FOUND,
                                        "Product Id: " + productId + " not found!"));
        //This is  a microservice call
        DepartmentDto dept = departmentClient.getDepartmentById(product.getDepartment());

        return new ProductResponseDto(
                product.getId(), product.getName(), product.getPrice(), dept);

    }
}
