package com.example.productAPI.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class ProductResponseDto {

    Long id;
    String name;
    Float price;
    DepartmentDto departmentDto;
}
