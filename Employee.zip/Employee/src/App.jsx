import './App.css'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from './components/Navbar'
import EmployeeList from './components/EmployeeList'
import EmployeeForm from './components/EmployeeForm'
import EmployeeDetails from './components/EmployeeDetails'
import UpdateEmployee from './components/UpdateEmployee';

function App() {
  return (
    <BrowserRouter>
      <div className='container-fluid px-0 py-4 py-md-5'>
        <div className='card border-0 shadow-sm rounded-0 overflow-hidden'>
          <div className='card-body p-3 p-md-4'>
            <h1 className='h3 h2-md mb-3 mb-md-4 text-center'>Employee Management System</h1>
            <Navbar />
            <Routes>
              <Route path='/' element={<EmployeeList />} />
              <Route path='/add-employee' element={<EmployeeForm />} />
              <Route path='/employees/:id' element={<EmployeeDetails />} />
              <Route path='/update-employees/:id' element={<UpdateEmployee />} />
            </Routes>
          </div>
        </div>
      </div>
    </BrowserRouter>
  )
}

<BrowserRouter>
  <div className='container-fluid px-0 py-4 py-md-5'>
    <div className='card border-0 shadow-sm rounded-0 overflow-hidden'>
      <div className='card-body p-3 p-md-4'>
        <h1 className='h3 h2-md mb-3 mb-md-4 text-center'>Employee Management System</h1>
        <Navbar />
        <Routes>
          <Route path='/' element={<EmployeeList />} />
          <Route path='/add-employee' element={<EmployeeForm />} />
          <Route path='/employees/:id' element={<EmployeeDetails />} />
          <Route path='/update-employees/:id' element={<UpdateEmployee />} />
        </Routes>
      </div>
    </div>
  </div>
</BrowserRouter>
export default App


