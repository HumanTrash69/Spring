import { useState } from "react";

export default function AuthProvider({ children }) {
    const [user, setuser] = useState(null);
    function login() {
        setuser({ name: "ABC", role: "Student" });
    }
    function logout() {
        setUser(null);
    }
    return (
        <AuthContext.Provider value={{ user, login, logout }}>
            (children)
        </AuthContext.Provider>
    );
}