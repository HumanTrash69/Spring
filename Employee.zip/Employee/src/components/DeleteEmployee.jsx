import axios from "axios";
import { useState } from "react"
 
function DeleteEmployee({employeeId, getAllEmployee}) {
    const [errorMessage, setErrorMessage] = useState("");
 
    const deleteEmployee =  () => {
            console.log(employeeId);
            axios.delete("http://localhost:8083/api/employee/"+employeeId)
            .then(()=> {
                console.log("Employee Suceessfully Deleted")
 
                getAllEmployee();
                setErrorMessage("");
            })
            .catch ((error) => {
            console.error("Error deleting employee:", error);
            if (error.response && error.response.data.message) {
                setErrorMessage(error.response.data.message);
            } else {
                setErrorMessage("Something went wrong while deleting the employee");
            }
        })
    };
  return (
    <div>
                <button onClick={deleteEmployee} className='btn btn-danger delete-btn'>Delete</button>
        {errorMessage && <p className="error-message">{errorMessage}</p>}
    </div>
  )
}
 
export default DeleteEmployee