import { createContext } from "react";

const AuthContect = createContext(null);


export default AuthContext;