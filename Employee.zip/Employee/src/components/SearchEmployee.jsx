function SearchEmployee({ searchTerm, onSearchChange }) {
	return (
		<div className="search-bar">
			<label htmlFor="employee-search" className="search-label">
				Search employees
			</label>
			<input
				id="employee-search"
				type="text"
				className="search-input"
				placeholder="Search by name, department, email, code, designation, salary..."
				value={searchTerm}
				onChange={(event) => onSearchChange(event.target.value)}
			/>
		</div>
	)
}

export default SearchEmployee
