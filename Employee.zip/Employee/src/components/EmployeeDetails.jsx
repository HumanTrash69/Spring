import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

function EmployeeDetails() {
    const [employee, setEmployee] = useState(null);
    const [errorMessage, setErrorMessage] = useState("");

    const { id } = useParams();

    useEffect(() => {
        axios.get("http://localhost:8083/api/employee/" + id)
            .then((response) => {
                console.log("Employee Fetched is", response.data);
                setEmployee(response.data);
                setErrorMessage("");
            })
            .catch((error) => {
                console.log("Error while fetching employee", error);
                if (error.response && error.response.data.message) {
                    setErrorMessage(error.response.data.message);
                } else {
                    setErrorMessage("Something went wrong while fetching employee");
                }
            });
    }, [id]);

    const detailRows = employee ? [
        ["Employee Code", employee.employeeCode],
        ["Name", employee.name],
        ["Email", employee.email],
        ["Department", employee.department],
        ["Designation", employee.designation],
        ["Salary", employee.salary],
        ["Joining Date", employee.joiningDate],
        ["Status", employee.active ? "Active" : "Inactive"],
    ] : [];

    return (
        <div className="details-section">
            <h2>Employee Details</h2>

            {errorMessage && (
                <p className="error-message">{errorMessage}</p>
            )}

            {!errorMessage && !employee && (
                <p className="details-loading">Loading employee details...</p>
            )}

            {employee && (
                <div className="details-card">
                    {detailRows.map(([label, value]) => (
                        <div key={label} className="details-row">
                            <p className="details-label">{label}</p>
                            <p className="details-value">{value ?? "-"}</p>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}

export default EmployeeDetails;