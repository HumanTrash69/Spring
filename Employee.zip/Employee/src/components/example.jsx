import { useState } from "react";


export default function example() {

    const [count, setCount] = useState(0);
    const [name, setName] = useState("");

    console.log("Component rendered");

    return (
        <div>

        </div>
    )
}