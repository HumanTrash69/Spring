// ...existing code...
import React, { useState } from 'react';

function ArrayOfObjects() {
    const [employees, setEmployees] = useState([
        { id: 1, name: "Rahul", salary: 50000 },
        { id: 2, name: "Priya", salary: 60000 },
        { id: 3, name: "Amit", salary: 45000 }
    ]);

    const updateSalary = (id, amount) => {
        setEmployees(prev => prev.map(emp => emp.id === id ? { ...emp, salary: emp.salary + amount } : emp));
    };

    console.log("Employees:", employees);

    return (
        <div>
            <h2>Employees</h2>
            {employees.map(emp => (
                <div key={emp.id}>
                    <h3>Employee Id: {emp.id}</h3>
                    <p>Employee Name: {emp.name}</p>
                    <p>Employee Salary: {emp.salary}</p>
                    <button onClick={() => updateSalary(emp.id, 5000)}> Update Salary </button>
                </div>
            ))}
        </div>
    );
}

export default ArrayOfObjects;