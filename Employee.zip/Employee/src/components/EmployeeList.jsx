import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import axios from "axios";
import DeleteEmployee from './DeleteEmployee';
import SearchEmployee from './SearchEmployee';

export default function EmployeeList() {

  const [employees, setEmployees] = useState([]);
  const [error, setError] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  const getAllEmployee = () => {
    axios.get("http://localhost:8083/api/employee")
      .then((response) => {
        console.log("employees fetched are", response.data);
        setEmployees(response.data);
        setError("");
      })
      .catch((error) => {
        console.log("Error fetching Emplyees", error);
        if (error.response && error.response.data.message) {
          setError(error.response.data.message);
        } else {
          setError("Something went wrong while fetching")
        }
      })
  }

  useEffect(() => {
    getAllEmployee();
  }, []);

  const filteredEmployees = employees.filter((employee) => {
    const searchableText = [
      employee.Id,
      employee.employeeCode,
      employee.name,
      employee.email,
      employee.department,
      employee.designation,
      employee.salary,
      employee.joiningDate,
      employee.active ? "active" : "inactive",
    ]
      .filter((value) => value !== null && value !== undefined)
      .join(" ")
      .toLowerCase();

    return searchableText.includes(searchTerm.toLowerCase().trim());
  });

  return (
    <div className='list-section'>
      <h2>EmployeeList</h2>
      <SearchEmployee searchTerm={searchTerm} onSearchChange={setSearchTerm} />
      {error && (
        <p className='error-message'>{error}</p>
      )}
      {employees.length === 0 ? (
        <p> No Employee Available</p>
      ) : filteredEmployees.length === 0 ? (
        <p>No employees match your search.</p>
      ) : (
        <div className="table-wrapper">
          <table className='employee-table'>
            <thead>
              <tr>
                <th>ID</th>
                <th>Code</th>
                <th>Name</th>
                <th>Email</th>
                <th>Department</th>
                <th>Designation</th>
                <th>Salary</th>
                <th>Joining Date</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {
                filteredEmployees.map((emp) => (
                  <tr key={emp.Id}>
                    <td>{emp.Id}</td>
                    <td>{emp.employeeCode}</td>
                    <td>{emp.name}</td>
                    <td>{emp.email}</td>
                    <td>{emp.department}</td>
                    <td>{emp.designation}</td>
                    <td>{emp.salary}</td>
                    <td>{emp.joiningDate}</td>
                    <td>{emp.active ? "Active" : "Inactive"}</td>
                    <td>
                      <div className="action-buttons">
                        <Link to={'/employees/' + emp.Id} className="view-btn">View</Link>
                        <Link to={"/update-employees/" + emp.Id} className='edit-btn'>Edit</Link>
                        <DeleteEmployee employeeId={emp.Id}
                          getAllEmployee={getAllEmployee} />
                      </div>
                    </td>
                  </tr>
                ))
              }
            </tbody>
          </table>
        </div>
      )
      }
    </div >
  )
}
