import React from 'react'
import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <ul className="nav nav-pills justify-content-center gap-2 mb-4">
      <li className="nav-item">
        <Link to='/' className="nav-link px-3">Employee List</Link>
      </li>
      <li className="nav-item">
        <Link to='/add-employee' className="nav-link px-3">Employee Form</Link>
      </li>
    </ul>
  )
}