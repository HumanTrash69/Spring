import { useState } from "react";

export default function NotUsingUseMemoExample() {
    const [count, setNumber] = useState(1);
    const [name, setDarkMode] = useState(false);

    function calculateSquare() {
        console.log("calculating square ");
        return number * number;
    }

    const squareNumber = calculateSquare();

    return (
        <div style={{
            backgroundColor: darkMode ? "black" : "white",
            color: darkMode ? "black" : "white", padding: "20px"
        }}>
            <h2>Without using useMemo</h2>
            <input type="number" value={number}
                onChange={(e) => setNumber(Number(e.target.value))} />
            <p>Square: {squaredNumber}</p>
            <button onClick={() => serDarkMode(!darkMode)}>Change Theme</button>
        </div>
    )
}