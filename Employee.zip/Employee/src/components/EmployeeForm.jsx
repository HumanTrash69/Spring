import axios from "axios";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

function EmployeeForm() {

  const [employee, setEmployee] = useState({
    employeeCode: "",
    name: "",
    email: "",
    department: "",
    designation: "",
    salary: "",
    joiningDate: "",
    active: true
  });
  const [errors, setErrors] = useState({});
  const [errorMessage, setErrorMessage] = useState("");
  const navigate = useNavigate();

  function handleChange(event) {
    const { name, value, type, checked } = event.target;
    setEmployee({
      ...employee,
      [name]: type === "checkbox" ? checked : value
    });
  }

  function saveEmployee(event) {
    event.preventDefault();
    axios.post("http://localhost:8083/api/employee", employee)
      .then((response) => {
        console.log("Employee Saved", response.data);
        setEmployee({
          employeeCode: "", name: "", email: "", department: "",
          designation: "", salary: "", joiningDate: "", active: true

        });
        setErrorMessage("");
        setErrors({});
        navigate("/");
      })
      .catch((error) => {
        console.log("Error while saving employee", error);
        if (error.response && error.response.status === 400) {
          setErrors(error.response.data.errors || {});
          setErrorMessage("");
        } else if (error.response && error.response.data.message) {
          setErrorMessage(error.response.data.message);
          setErrors({});
        } else {
          setErrorMessage("Something went wrong while saving employee");
          setErrors({});
        }
      });
  }

  return (
    <div className="card border-0 shadow-sm rounded-4">
      <div className="card-body p-3 p-md-4">
        <h2 className="h4 mb-3">Employee Form</h2>
        {errorMessage && <div className="alert alert-danger" role="alert">{errorMessage}</div>}
        <form onSubmit={saveEmployee} className="row g-3">
          <div className="col-12 col-md-6">
            <label className="form-label">Employee Code</label>
            <input type="text" name="employeeCode" onChange={handleChange} placeholder="Enter Employee Code" value={employee.employeeCode} className="form-control" />
            {errors.employeeCode && <div className="text-danger small mt-1">{errors.employeeCode}</div>}
          </div>
          <div className="col-12 col-md-6">
            <label className="form-label">Employee Name</label>
            <input type="text" name="name" onChange={handleChange} placeholder="Enter Name" value={employee.name} className="form-control" />
            {errors.name && <div className="text-danger small mt-1">{errors.name}</div>}
          </div>
          <div className="col-12 col-md-6">
            <label className="form-label">Employee Email</label>
            <input type="email" name="email" onChange={handleChange} placeholder="Enter Employee Email" value={employee.email} className="form-control" />
            {errors.email && <div className="text-danger small mt-1">{errors.email}</div>}
          </div>
          <div className="col-12 col-md-6">
            <label className="form-label">Department</label>
            <input type="text" name="department" onChange={handleChange} placeholder="Enter Department" value={employee.department} className="form-control" />
            {errors.department && <div className="text-danger small mt-1">{errors.department}</div>}
          </div>
          <div className="col-12 col-md-6">
            <label className="form-label">Designation</label>
            <input type="text" name="designation" onChange={handleChange} placeholder="Enter Designation" value={employee.designation} className="form-control" />
            {errors.designation && <div className="text-danger small mt-1">{errors.designation}</div>}
          </div>
          <div className="col-12 col-md-6">
            <label className="form-label">Salary</label>
            <input type="number" name="salary" onChange={handleChange} placeholder="Enter Salary" value={employee.salary} className="form-control" />
            {errors.salary && <div className="text-danger small mt-1">{errors.salary}</div>}
          </div>
          <div className="col-12 col-md-6">
            <label className="form-label">Joining Date</label>
            <input type="date" name="joiningDate" onChange={handleChange} value={employee.joiningDate} className="form-control" />
            {errors.joiningDate && <div className="text-danger small mt-1">{errors.joiningDate}</div>}
          </div>
          <div className="col-12 col-md-6 d-flex align-items-center">
            <div className="form-check mt-4 mt-md-0">
              <input type="checkbox" checked={employee.active} name="active" onChange={handleChange} value={employee.active} className="form-check-input" id="activeEmployee" />
              <label className="form-check-label" htmlFor="activeEmployee">Active Employee</label>
            </div>
            {errors.active && <div className="text-danger small ms-3">{errors.active}</div>}
          </div>
          <div className="col-12">
            <button type="submit" className="btn btn-primary px-4">Submit</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default EmployeeForm