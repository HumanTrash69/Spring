import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

export default function UpdateEmployee() {

    const [employee, setEmployee] = useState({
        name: "",
        email: "",
        department: "",
        designation: "",
        salary: "",
        joiningDate: "",
        active: true

    });
    const [employeeCode, setEmployeeCode] = useState("");
    const [errors, setErrors] = useState({});
    const [errorMessage, setErrorMessage] = useState("");


    const { id } = useParams();
    const navigate = useNavigate();

    useEffect(() => {
        axios.get("http://localhost:8083/api/employee/" + id)
            .then(response => {
                console.log(response.data);
                const data = response.data;
                setEmployeeCode(data.employeeCode);
                setEmployee({
                    name: data.name,
                    email: data.email,
                    department: data.department,
                    designation: data.designation,
                    salary: data.salary,
                    joiningDate: data.joiningDate,
                    active: data.active
                });
                setErrorMessage("");
                setErrors({});
            })
            .catch(err => {
                console.error("Error while fetching employee", err)
                if (err.response && err.response.data.message) {
                    setErrorMessage(err.response.data.message);
                } else {
                    setErrorMessage("something went wrong while fetching the employee");
                }
            })
    }, [id])

    const updateEmployee = (e) => {
        e.preventDefault();
        axios.put("http://localhost:8083/api/employee/" + id, employee)
            .then(response => {
                console.log(response.data);
                setErrorMessage("");
                setErrors({});
                navigate("/");
            }).catch(error => {
                console.log("Error while saving the product", error)
                if (error.response && error.response.status === 400) {
                    setErrors(error.response.data.map || {});
                    setErrorMessage("");
                } else if (error.response && error.response.data.message) {
                    setErrorMessage(error.response.data.message);
                    setErrors({});
                } else {
                    setErrorMessage("Something went wrong while serving employee");
                    setErrors({});
                }
            });
    }

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setEmployee({
            ...employee,
            [name]: type === "checkbox" ? checked : value
        });
        setErrors({
            ...errors,
            [name]: ""
        })

    }

    return (
        <div className="form-wrapper">
            <h2>Employee Updation Form</h2>
            {errorMessage && <p className="error-message">  {errorMessage}</p>}
            <form onSubmit={updateEmployee}>
                <div className="form-group">
                    <label><strong>Employee Code</strong></label>
                    <h4>{employeeCode}</h4>
                    {
                        errors.employeeCode && (
                            <p className="field-error">{errors.employeeCode}</p>
                        )
                    }
                </div>
                <div className="form-group">
                    <label>Employee Name</label>
                    <input type="text" name="name" onChange={handleChange} placeholder="Enter Name  " value={employee.name} />
                    {
                        errors.name && (
                            <p className="field-error">{errors.name}</p>
                        )
                    }
                </div>
                <div className="form-group">
                    <label>Empoyee Email </label>
                    <input type="email" name="email" onChange={handleChange} placeholder="Enter Employee email " value={employee.email} />
                    {
                        errors.email && (
                            <p className="field-error">{errors.email}</p>
                        )
                    }
                </div>
                <div className="form-group">
                    <label>Employee department</label>
                    <input type="text" name="department" onChange={handleChange} placeholder="Enter Employee department " value={employee.department} />
                    {
                        errors.department && (
                            <p className="field-error">{errors.department}</p>
                        )
                    }
                </div>
                <div className="form-group">
                    <label>Employee designation</label>
                    <input type="text" name="designation" onChange={handleChange} placeholder="Enter Employee designation " value={employee.designation} />
                    {
                        errors.designation && (
                            <p className="field-error">{errors.designation}</p>
                        )
                    }
                </div>
                <div className="form-group">
                    <label>Employee salary</label>
                    <input type="number" name="salary" onChange={handleChange} placeholder="Enter Employee salary " value={employee.salary} />
                    {
                        errors.salary && (
                            <p className="field-error">{errors.salary}</p>
                        )
                    }
                </div>
                <div className="form-group">
                    <label>Employee Joining Date</label>
                    <input type="date" name="joiningDate" onChange={handleChange} placeholder="Enter Employee Joining Date " value={employee.joiningDate} />
                    {
                        errors.joiningDate && (
                            <p className="field-error">{errors.joiningDate}</p>
                        )
                    }
                </div>
                <div className="form-group">
                    <label>
                        <input type="checkbox" checked={employee.active} name="active" onChange={handleChange} value={employee.active} />
                        Active Employee
                    </label>
                    {
                        errors.active && (
                            <p className="field-error">{errors.active}</p>
                        )
                    }
                </div>
                <button type="submit" className="save-btn">Submit</button>
            </form>
        </div>
    )
}
