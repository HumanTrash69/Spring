package com.example.EmployeeFullStack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeFullStackApplicationTests {

	@Test
	void contextLoads() {
	}

}
