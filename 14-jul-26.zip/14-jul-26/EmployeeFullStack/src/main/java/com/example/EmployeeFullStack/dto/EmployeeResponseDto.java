package com.example.EmployeeFullStack.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeResponseDto {

    private Long Id;
    private String name;
    private String employeeCode;
    private String email;
    private String department;
    private String designation;
    private BigDecimal salary;
    private LocalDate joiningDate;
    private Boolean active;
}
