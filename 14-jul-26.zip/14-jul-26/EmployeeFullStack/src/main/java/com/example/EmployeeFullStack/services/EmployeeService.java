package com.example.EmployeeFullStack.services;

import com.example.EmployeeFullStack.dto.EmployeeRequestDto;
import com.example.EmployeeFullStack.dto.EmployeeResponseDto;
import com.example.EmployeeFullStack.dto.EmployeeUpdateDto;

import java.util.*;
public interface EmployeeService {

    public EmployeeResponseDto createEmployee(EmployeeRequestDto employeeRequestDto);

    public List<EmployeeResponseDto> getAllEmployee();

    public EmployeeResponseDto getEmployeeById(Long Id);

    public EmployeeResponseDto updateEmployee(Long id, EmployeeUpdateDto employeeUpdateDto);

    void deleteEmployee(Long Id);
}
