package com.example.EmployeeFullStack.controller;


import com.example.EmployeeFullStack.dto.EmployeeRequestDto;
import com.example.EmployeeFullStack.dto.EmployeeResponseDto;
import com.example.EmployeeFullStack.services.EmployeeService;
import jakarta.validation.Valid;
import org.springframework.data.annotation.Id;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employee")
@CrossOrigin(origins = "*")
public class EmployeeController {
    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public EmployeeResponseDto create(@Valid @RequestBody EmployeeRequestDto employeeRequestDto) {
        return employeeService.createEmployee(employeeRequestDto);
    }


    @GetMapping
    public List<EmployeeResponseDto> getAllEmployee() {
        return employeeService.getAllEmployee();
    }

    @GetMapping("/{id}")
    public EmployeeResponseDto getBookingById(@PathVariable Long id) {
        return employeeService.getEmployeeById(id);
    }


}