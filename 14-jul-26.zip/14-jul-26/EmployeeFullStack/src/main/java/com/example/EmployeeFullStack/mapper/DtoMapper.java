package com.example.EmployeeFullStack.mapper;

import com.example.EmployeeFullStack.dto.EmployeeRequestDto;
import com.example.EmployeeFullStack.dto.EmployeeResponseDto;
import com.example.EmployeeFullStack.dto.EmployeeUpdateDto;
import com.example.EmployeeFullStack.entity.Employee;

public class DtoMapper {

    public static Employee toEntity(EmployeeRequestDto dto){
        Employee employee = new Employee();
        employee.setName(dto.getName());
        employee.setEmployeeCode(dto.getEmployeeCode());
        employee.setEmail(dto.getEmail());
        employee.setDepartment(dto.getDepartment());
        employee.setDesignation(dto.getDesignation());
        employee.setSalary(dto.getSalary());
        employee.setJoiningDate(dto.getJoiningDate());
        employee.setActive(dto.getActive());
        return employee;
    }

    public static EmployeeResponseDto toDto(Employee employee){
        EmployeeResponseDto dto = new EmployeeResponseDto();
        dto.setId(employee.getId());
        dto.setName(employee.getName());
        dto.setEmployeeCode(employee.getEmployeeCode());
        dto.setEmail(employee.getEmail());
        dto.setDepartment(employee.getDepartment());
        dto.setDesignation(employee.getDesignation());
        dto.setSalary(employee.getSalary());
        dto.setJoiningDate(employee.getJoiningDate());
        dto.setActive(employee.getActive());
        return dto;
    }

    public static void updateEntity(Employee employee, EmployeeUpdateDto dto){

        employee.setName(dto.getName());
        employee.setEmail(dto.getEmail());
        employee.setDepartment(dto.getDepartment());
        employee.setDesignation(dto.getDesignation());
        employee.setSalary(dto.getSalary());
        employee.setJoiningDate(dto.getJoiningDate());
        employee.setActive(dto.getActive());
    }
}
