package com.example.EmployeeFullStack.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Table(name="Employee")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;

    @NotBlank(message="Name cannot be blank")
    @Size(min = 2, max = 50, message = "Name must be between 2 abd 50 characters")
    @Column(nullable = false)
    private String name;

    @NotBlank(message="EmployeeCode cannot be blank")
    @Size(min = 2, max = 50, message = "emp code must be between 2 abd 50 characters")
    @Column(nullable = false)
    private String employeeCode;

    @NotBlank(message="Email cannot be blank")
    @Size(min = 2, max = 50, message = "Email must be between 2 abd 50 characters")
    @Email
    @Column(nullable = false)
    private String email;

    @NotBlank(message="Department cannot be blank")
    @Size(min = 2, max = 50, message = "Department must be between 2 abd 50 characters")
    @Column(nullable = false)
    private String department;

    @NotBlank(message="Designation cannot be blank")
    @Size(min = 2, max = 50, message = "Designation must be between 2 abd 50 characters")
    @Column(nullable = false)
    private String designation;

    @NotNull(message = "Salary cannot be null")
    @Positive(message = "Salary must be greater than zero")
    @Digits(integer = 8, fraction = 2, message = "Salary should have maximum  8 digits and 2 decimal places")
    @Column(nullable = false)
    private BigDecimal salary;

    @NotNull(message = "Joining date cannot be null")
    @PastOrPresent(message = "Joining date cannot be in future")
    @Column(nullable = false)
    private LocalDate joiningDate;

    @NotNull(message = "Active status cannot be null")
    @Column(nullable = false)
    private Boolean active;

}
