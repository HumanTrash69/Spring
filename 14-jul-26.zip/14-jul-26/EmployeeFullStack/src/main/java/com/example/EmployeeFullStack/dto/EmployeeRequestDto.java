package com.example.EmployeeFullStack.dto;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeRequestDto {

    @NotBlank(message="Name cannot be blank")
    @Size(min = 2, max = 50, message = "Name must be between 2 abd 50 characters")
    @Column(nullable = false)
    private String name;

    @NotBlank(message="EmployeeCode cannot be blank")
    @Size(min = 2, max = 50, message = "emp code must be between 2 abd 50 characters")
    @Column(nullable = false)
    private String employeeCode;

    @NotBlank(message="Email cannot be blank")
    @Size(min = 2, max = 50, message = "Email must be between 2 abd 50 characters")
    @Email
    @Column(nullable = false)
    private String email;

    @NotBlank(message="Department cannot be blank")
    @Size(min = 2, max = 50, message = "Department must be between 2 abd 50 characters")
    @Column(nullable = false)
    private String department;

    @NotBlank(message="Designation cannot be blank")
    @Size(min = 2, max = 50, message = "Designation must be between 2 abd 50 characters")
    @Column(nullable = false)
    private String designation;

    @NotNull(message = "Salary cannot be null")
    @Positive(message = "Salary must be greater than zero")
    @Digits(integer = 8, fraction = 2, message = "Salary should have maximum  8 digits and 2 decimal places")
    @Column(nullable = false)
    private BigDecimal salary;

    @NotNull(message = "Joining date cannot be null")
    @PastOrPresent(message = "Joining date cannot be in future")
    @Column(nullable = false)
    private LocalDate joiningDate;

    @NotNull(message = "Active status cannot be null")
    @Column(nullable = false)
    private Boolean active;
}
