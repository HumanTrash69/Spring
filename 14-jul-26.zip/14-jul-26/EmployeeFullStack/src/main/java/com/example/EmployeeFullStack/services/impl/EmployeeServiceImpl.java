package com.example.EmployeeFullStack.services.impl;

import com.example.EmployeeFullStack.dto.EmployeeRequestDto;
import com.example.EmployeeFullStack.dto.EmployeeResponseDto;
import com.example.EmployeeFullStack.dto.EmployeeUpdateDto;
import com.example.EmployeeFullStack.entity.Employee;
import com.example.EmployeeFullStack.exception.DuplicateEmployeeException;
import com.example.EmployeeFullStack.exception.EmployeeNotFoundException;
import com.example.EmployeeFullStack.mapper.DtoMapper;
import com.example.EmployeeFullStack.repo.EmployeeRepository;
import com.example.EmployeeFullStack.services.EmployeeService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    public final EmployeeRepository employeeRepository;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository){
        this.employeeRepository = employeeRepository;
    }

    @Override
    public EmployeeResponseDto createEmployee(EmployeeRequestDto employeeRequestDto) {
        if(employeeRepository.existsByEmail(employeeRequestDto.getEmail())){
            throw new DuplicateEmployeeException("Employee already exists with " + "email: " + employeeRequestDto.getEmail());
        }

        if(employeeRepository.existsByEmployeeCode(employeeRequestDto.getEmployeeCode())){
            throw new DuplicateEmployeeException("Employee already exists with " + "code: " + employeeRequestDto.getEmployeeCode());
        }

        Employee employee = DtoMapper.toEntity(employeeRequestDto);
        Employee savedEmployee = employeeRepository.save(employee);
        return DtoMapper.toDto(savedEmployee);
    }

    @Override
    public List<EmployeeResponseDto> getAllEmployee() {
        return employeeRepository.findAll().stream().map(DtoMapper::toDto).toList();
    }

    @Override
    public EmployeeResponseDto getEmployeeById(Long Id) {
        Employee existingEmployee = employeeRepository.findById(Id).orElseThrow(()->
                new EmployeeNotFoundException("Employee not found with id: "+ Id));
        return DtoMapper.toDto(existingEmployee);
    }

    @Override
    public EmployeeResponseDto updateEmployee(Long id, EmployeeUpdateDto employeeUpdateDto) {
        Employee existingEmployee = employeeRepository.findById(id).orElseThrow(() -> new EmployeeNotFoundException("Employee not Found with id: " + id));
        if(employeeRepository.existsByEmailAndIdNot(employeeUpdateDto.getEmail(), id)){
            throw new DuplicateEmployeeException("Employee Already exists with email: "+ employeeUpdateDto.getEmail());
        }
        DtoMapper.updateEntity(existingEmployee, employeeUpdateDto);
        Employee updatedEmployee = employeeRepository.save(existingEmployee);
        return DtoMapper.toDto(updatedEmployee);
    }

    @Override
    public void deleteEmployee(Long Id) {
        Employee existingEmployee = employeeRepository.findById(Id).orElseThrow(()->
               new EmployeeNotFoundException("Employee not found with id: " +Id));
        employeeRepository.deleteById(Id);

    }
}
