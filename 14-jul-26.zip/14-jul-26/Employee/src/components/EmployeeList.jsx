import React, { useEffect, useState } from 'react'
import axios from "axios";
export default function EmployeeList() {
 
   const [employees, setEmployees] = useState([]);
   const [error, setError] = useState("");
 
  const getAllEmployee = () => {
    axios.get("http://localhost:8083/api/employee")
    .then((response)=>{
        console.log("employees fetched are", response.data);
        setEmployees(response.data);
        setError("");
    })
    .catch((error)=> {
        console.log("Error fetching Emplyees", error);
        if(error.response && error.response.data.message){
            setError(error.response.data.message);
        } else {
            setError("Something went wrong while fetching")
        }
    })
  }
 
  useEffect(()=>{
    getAllEmployee();
  },[]);
 
  return (
    <div className='list-section'>
      <h2>EmployeeList</h2>
      {error && (
        <p className='error-message'>{error}</p>
      )}
      {employees.length === 0 ? (
        <p> No Employee Available</p>
      ): (
        <div className="table-wrapper">
          <table className='employee-table'>
            <thead>
              <tr>
                <th>ID</th>
                <th>Code</th>
                <th>Name</th>
                <th>Email</th>
                <th>Department</th>
                <th>Designation</th>
                <th>Salary</th>
                <th>Joining Date</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {
                employees.map((emp)=>(
                  <tr key={emp.id}>
                    <td>{emp.id}</td>
                    <td>{emp.employeeCode}</td>
                    <td>{emp.name}</td>
                    <td>{emp.email}</td>
                    <td>{emp.department}</td>
                    <td>{emp.designation}</td>
                    <td>{emp.salary}</td>
                    <td>{emp.joiningDate}</td>
                    <td>{emp.active ? "Active" : "Inactive"}</td>
                    <th>Actions</th>
                  </tr>
 
                ))
              }
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
 