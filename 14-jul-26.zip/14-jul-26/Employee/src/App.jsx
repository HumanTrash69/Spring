
import './App.css'
import Navbar from './components/Navbar'
import EmployeeList from './components/EmployeeList'
import { BrowserRouter, Routes, Route } from "react-router-dom";


function App() {

  return (
    <BrowserRouter>
      <div className='app-container'>
        <h1 className='app-title'>Employee Management System</h1>
        <Navbar />
        <Routes>
          <Route path='/' element={<EmployeeList />} />
        </Routes>
      </div>
    </BrowserRouter>
  )
}

export default App

