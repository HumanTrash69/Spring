package com.example.SpringProject.exception;

public class ResourseNotFoundException extends Exception{
    public ResourseNotFoundException(String message){
        super(message);
    }
}
