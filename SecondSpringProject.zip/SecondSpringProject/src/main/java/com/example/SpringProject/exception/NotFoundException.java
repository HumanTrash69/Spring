package com.example.SpringProject.exception;

public class NotFoundException extends Exception{

    public NotFoundException(String message){
        super(message);
    }

}
