package com.example.SpringProject.service;

import com.example.SpringProject.dto.CourseResponse;
import com.example.SpringProject.dto.CreateCourseRequest;
import com.example.SpringProject.dto.UpdateCourseRequest;
import com.example.SpringProject.exception.NotFoundException;
import com.example.SpringProject.exception.ResourseNotFoundException;
import com.example.SpringProject.mapper.dtomapper;
import com.example.SpringProject.model.Course;
import com.example.SpringProject.repository.CourseRepository;
import org.springframework.data.crossstore.ChangeSetPersister;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CourseService {

    private final CourseRepository courseRepository;

    public CourseService(CourseRepository courseRepository){
        this.courseRepository = courseRepository;
    }

    @Transactional(readOnly = false)
    public CourseResponse create(CreateCourseRequest request){
        Course course = dtomapper.fromCreate(request);
        Course savedCourse = courseRepository.save(course);
        CourseResponse response = dtomapper.toResponse(savedCourse);
        return response;
    }


    @Transactional(readOnly = true)

    public List<CourseResponse> getall(){
        return courseRepository.findAll().stream().map(this::toResponse).toList();
    }
    public CourseResponse toResponse(Course u){
        return new CourseResponse(u.getId(), u.getCode(), u.getTitle(), u.getDescription(), u.getFee(), u.isActive(), u.getCreatedAt());
    }

    @Transactional(readOnly = false)
    public CourseResponse update(Long id, UpdateCourseRequest request) throws NotFoundException {
        Course existinguser = courseRepository.findById(id).orElseThrow(() -> new NotFoundException("user:"+ id + " Not found"));
        existinguser.setTitle(request.getTitle());
        existinguser.setCode(request.getCode());
        existinguser.setFee(request.getFee());
        existinguser.setDescription(request.getDescription());

        Course saveduser=courseRepository.save(existinguser);
        return toResponse(saveduser);

    }


    @Transactional(readOnly = true)
    public CourseResponse getbyid(Long id) throws NotFoundException {
        Course existinguser = courseRepository.findById(id).orElseThrow(() -> new NotFoundException("Course:"+ id + " Not found"));
        return toResponse(existinguser);
    }
    @Transactional(readOnly = true)
    public CourseResponse getbytitle(String title) throws NotFoundException {
        Course existinguser = courseRepository.findByTitle(title).orElseThrow(() -> new NotFoundException("Course:"+ title + " Not found"));
        return toResponse(existinguser);
    }

    public CourseResponse getbyid1(Long id) throws ResourseNotFoundException {
        Course existinguser = courseRepository.findById(id).orElseThrow(() -> new ResourseNotFoundException("Course:"+ id + " Not found"));
        return dtomapper.toResponse(existinguser);
    }
}
