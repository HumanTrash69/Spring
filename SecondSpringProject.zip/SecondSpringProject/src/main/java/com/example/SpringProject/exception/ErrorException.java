package com.example.SpringProject.exception;

public class ErrorException {

    private final String message;

    public ErrorException(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
