package com.example.SpringProject.web;

import com.example.SpringProject.dto.CourseResponse;
import com.example.SpringProject.dto.CreateCourseRequest;
import com.example.SpringProject.dto.UpdateCourseRequest;
import com.example.SpringProject.exception.NotFoundException;
import com.example.SpringProject.exception.ResourseNotFoundException;
import com.example.SpringProject.service.CourseService;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/courses")
public class CourseController {

    @Autowired
    private CourseService courseService;

    @PostMapping
    public ResponseEntity<CourseResponse> create(@RequestBody CreateCourseRequest request){
        CourseResponse response = courseService.create(request);
        return ResponseEntity.status(201).body(response);
    }

    @GetMapping
    public List<CourseResponse> getAll(){
        return courseService.getall();
    }

    @GetMapping("/api2")
    public ResponseEntity<List<CourseResponse>> allCourse(){
        List<CourseResponse> allCourse = courseService.getall();
        if(allCourse.isEmpty()){
            return ResponseEntity.status(404).build();
        }
        return ResponseEntity.status(200).body(allCourse);
    }

    @GetMapping("/{id}")
    public CourseResponse getbyid(@PathVariable("id") Long id) throws NotFoundException {
        return courseService.getbyid(id);
    }

    @GetMapping("/api2/{id}")
    public ResponseEntity<CourseResponse> getbyCourseId(@PathVariable("id") Long id) throws ResourseNotFoundException {
        if (id < 0){
            return ResponseEntity.status(400).build();
        }
        return new ResponseEntity<CourseResponse>(courseService.getbyid1(id), HttpStatus.OK);
    }
//    @GetMapping("/{title}")
//    public CourseResponse getbytitle(@PathVariable("title") String title) throws NotFoundException {
//        return courseService.getbytitle(title);
//    }


    @PutMapping("/{id}")
    public CourseResponse update(@PathVariable("id")Long id,@RequestBody UpdateCourseRequest request) throws NotFoundException {
        return courseService.update(id,request);
    }

}
