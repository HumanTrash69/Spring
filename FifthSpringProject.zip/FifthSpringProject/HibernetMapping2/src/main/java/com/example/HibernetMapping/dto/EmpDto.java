package com.example.HibernetMapping.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter @Getter @NoArgsConstructor
@AllArgsConstructor
public class EmpDto {
    private Long empId;
    private String empName;
    private Double salary;
    private Long departmentId;
    private String departmentName;
}