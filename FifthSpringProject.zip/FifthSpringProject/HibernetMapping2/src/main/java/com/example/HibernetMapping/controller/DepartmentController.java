package com.example.HibernetMapping.controller;

import com.example.HibernetMapping.dto.EmpDto;
import com.example.HibernetMapping.model.Department;
import com.example.HibernetMapping.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class DepartmentController {

    @Autowired
    private EmployeeService employeeService;

    @PostMapping("/departments")
    public ResponseEntity<Department> createDepartment(@RequestBody Department department) {
        Department savedDept = employeeService.saveDepartment(department);
        return ResponseEntity.ok(savedDept);
    }

    @PostMapping("/employees")
    public ResponseEntity<EmpDto> createEmployee(@RequestBody EmpDto employeeDTO) {
        EmpDto savedEmployee = employeeService.saveEmployee(employeeDTO);
        return ResponseEntity.ok(savedEmployee);
    }

    @GetMapping("/departments/{depId}/employees")
    public ResponseEntity<List<EmpDto>> getEmployeesByDepartment(@PathVariable Long depId) {
        List<EmpDto> employees = employeeService.getEmployeesByDepartment(depId);
        return ResponseEntity.ok(employees);
    }
}