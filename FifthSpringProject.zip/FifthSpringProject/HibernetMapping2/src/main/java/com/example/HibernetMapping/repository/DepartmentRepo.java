package com.example.HibernetMapping.repository;

import com.example.HibernetMapping.model.Department;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentRepo extends JpaRepository<Department, Long> {
}
