package com.example.HibernetMapping.repository;

import com.example.HibernetMapping.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmpRepo extends JpaRepository<Employee, Long> {
    List<Employee> findByDepartmentDepId(Long depId);
}
