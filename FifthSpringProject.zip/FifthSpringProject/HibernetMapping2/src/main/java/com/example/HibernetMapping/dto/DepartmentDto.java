package com.example.HibernetMapping.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.List;

@Setter @Getter @NoArgsConstructor
@AllArgsConstructor
public class DepartmentDto {
    private Long depId;
    private String depName;
    private List<EmpDto> employees; // Optional: include if you want to see employees when fetching a department
}