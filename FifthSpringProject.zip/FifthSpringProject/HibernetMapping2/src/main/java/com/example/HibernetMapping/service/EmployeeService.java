package com.example.HibernetMapping.service;

import com.example.HibernetMapping.dto.EmpDto;
import com.example.HibernetMapping.mapper.EmployeeMapper;
import com.example.HibernetMapping.model.Department;
import com.example.HibernetMapping.model.Employee;
import com.example.HibernetMapping.repository.DepartmentRepo;
import com.example.HibernetMapping.repository.EmpRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeService {

    @Autowired
    private EmpRepo employeeRepository;

    @Autowired
    private DepartmentRepo departmentRepository;

    @Autowired
    private EmployeeMapper employeeMapper;

    public Department saveDepartment(Department department) {
        return departmentRepository.save(department);
    }

    public EmpDto saveEmployee(EmpDto employeeDTO) {
        Department department = departmentRepository.findById(employeeDTO.getDepartmentId())
                .orElseThrow(() -> new RuntimeException("Department not found with id: " + employeeDTO.getDepartmentId()));

        Employee employee = employeeMapper.toEntity(employeeDTO);
        employee.setDepartment(department);

        Employee savedEmployee = employeeRepository.save(employee);
        return employeeMapper.toDTO(savedEmployee);
    }

    public List<EmpDto> getEmployeesByDepartment(Long depId) {
        return employeeRepository.findByDepartmentDepId(depId)
                .stream()
                .map(employeeMapper::toDTO)
                .collect(Collectors.toList());
    }
}