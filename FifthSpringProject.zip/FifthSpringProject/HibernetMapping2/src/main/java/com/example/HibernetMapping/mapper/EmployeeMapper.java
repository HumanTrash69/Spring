package com.example.HibernetMapping.mapper;

import com.example.HibernetMapping.dto.EmpDto;
import com.example.HibernetMapping.model.Employee;
import org.springframework.stereotype.Component;

@Component
public class EmployeeMapper {

    public EmpDto toDTO(Employee employee) {
        if (employee == null) return null;

        EmpDto dto = new EmpDto();
        dto.setEmpId(employee.getEmpId());
        dto.setEmpName(employee.getEmpName());
        dto.setSalary(employee.getSalary());

        if (employee.getDepartment() != null) {
            dto.setDepartmentId(employee.getDepartment().getDepId());
            dto.setDepartmentName(employee.getDepartment().getDepName());
        }
        return dto;
    }

    public Employee toEntity(EmpDto dto) {
        if (dto == null) return null;

        Employee employee = new Employee();
        employee.setEmpId(dto.getEmpId());
        employee.setEmpName(dto.getEmpName());
        employee.setSalary(dto.getSalary());
        return employee;
    }
}