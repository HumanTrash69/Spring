package com.example.HibernetMapping.mapper;

import com.example.HibernetMapping.dto.*;
import com.example.HibernetMapping.model.*;

import java.util.List;
import java.util.Set;

public class DtoMapper2 {

    public static AddressDto toAddressDto(Address a) {
        return (a== null) ? null:
                new AddressDto(a.getLine1(), a.getCity(),
                        a.getState(), a.getZip());
    }

    public static CustomerDto toDto(Customer c){
        List<CustomerOrderDto> order =
                c.getOrders().stream().
                        map(DtoMapper2::toOrderDto).toList();
        return new CustomerDto(c.getId(), c.getName() ,
                c.getEmail(), toAddressDto(c.getAddress()), order);
    }

    public static CustomerOrderDto toOrderDto(CustomerOrder o){
        return new CustomerOrderDto(o.getId(), o.getOrderNumber());
    }

    public static ProfileDto toDto(Product p){
        Set<Category> category = <p.getCategories() == null) ? null: p.getCategories();
        return new ProductDto(p.getId(), p.getName(), category);
    }
}
