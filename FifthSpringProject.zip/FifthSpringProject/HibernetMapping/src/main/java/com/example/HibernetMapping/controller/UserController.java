package com.example.HibernetMapping.controller;

import com.example.HibernetMapping.dto.UserDto;
import com.example.HibernetMapping.mapper.DtoMapper;
import com.example.HibernetMapping.model.User;
import com.example.HibernetMapping.repo.UserRepository;
import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/user")
public class UserController {

    private final UserRepository userRepository;

    public UserController(UserRepository userRepository){
        this.userRepository = userRepository;
    }

    @PostMapping
    public ResponseEntity<UserDto> create(@RequestBody @Validated UserDto dto){
        User u = new User();
        DtoMapper.UpdateEntityFromDto(u, dto);
        User savedUser = userRepository.save(u);
        return ResponseEntity.status(201).body(DtoMapper.toDto(savedUser));
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserDto> getUserById(@PathVariable("id") Long id) {
        return userRepository.findById(id)
                .map(user -> ResponseEntity.ok(DtoMapper.toDto(user)))
                .orElse(ResponseEntity.notFound().build());
    }

//    @GetMapping
//    public ResponseEntity<java.util.List<UserDto>> getAllUsers() {
//        java.util.List<User> users = userRepository.findAll();
//        java.util.List<UserDto> dtos = new java.util.ArrayList<>();
//        for (User user : users) {
//            dtos.add(DtoMapper.toDto(user));
//        }
//        return ResponseEntity.ok(dtos);
//    }


    @GetMapping
    public ResponseEntity<java.util.List<UserDto>> getAllUsers() {
        java.util.List<User> users = userRepository.findAll();
        java.util.List<UserDto> dtos = users.stream()
                .map(DtoMapper::toDto)
                .collect(java.util.stream.Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable("id") Long id) {
        if (userRepository.existsById(id)) {
            userRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }


}
