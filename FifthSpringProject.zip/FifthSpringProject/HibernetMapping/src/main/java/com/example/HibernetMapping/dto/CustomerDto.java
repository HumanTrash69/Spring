package com.example.HibernetMapping.dto;

import java.util.*;

public record CustomerDto(Long id, String name, String email, AddressDto address, List<CustomerOrderDto> order) {
}
