package com.example.HibernetMapping.model;


import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "customers")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank @Column(nullable = false)
    private String name;

    @Email @Column(nullable = false ,unique = true)
    private String email;

    @Embedded
    private Address address;
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("customer-order")
    private List<CustomerOrder> orders = new ArrayList<>();

    public void addOrder(CustomerOrder order){
        orders.add(order);
        order.setCustomer(this);
    }
    public void removeOrder(CustomerOrder order){
        orders.remove(order);
        order.setCustomer(this);
    }
}
