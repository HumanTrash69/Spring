package com.example.HibernetMapping.mapper;

import com.example.HibernetMapping.dto.ProfileDto;
import com.example.HibernetMapping.dto.UserDto;
import com.example.HibernetMapping.model.Profile;
import com.example.HibernetMapping.model.User;

public final class DtoMapper {

    public static UserDto toDto(User u){
        ProfileDto profile = (u.getProfile() == null) ? null:
                new ProfileDto(u.getProfile().getId(),
                        u.getProfile().getFullName(),
                        u.getProfile().getPhone());

        return new UserDto(u.getId(), u.getUsername(), u.getEmail(), profile);
    }

    public static void UpdateEntityFromDto(User u, UserDto dto){
        u.setUsername(dto.username());
        u.setEmail(dto.email());
        if(dto.profile() !=null){
            Profile p = (u.getProfile()==null) ? new Profile(): u.getProfile();
            p.setFullName(dto.profile().fullName());
            p.setPhone(dto.profile().phone());

            p.setUser(u);
            u.setProfile(p);
        }
    }
}
