package com.example.HibernetMapping.dto;

public record UserDto(Long id, String username, String email, ProfileDto profile) {

}
