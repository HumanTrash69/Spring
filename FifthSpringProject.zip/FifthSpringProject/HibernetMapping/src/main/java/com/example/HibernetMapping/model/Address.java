package com.example.HibernetMapping.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Embeddable @Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Address {

    @Column(name="addr_line1", length =100)
    private String line1;

    @Column(name="addr_city", length = 50)
    private String city;

    @Column(name="addr_state", length = 50)
    private String state;

    @Column(name="addr_zip", length = 12)
    private String zip;
}
