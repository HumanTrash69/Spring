package com.example.HibernetMapping.controller;


import com.example.HibernetMapping.dto.ProductDto;
import com.example.HibernetMapping.mapper.DtoMapper2;
import com.example.HibernetMapping.model.Product;
import com.example.HibernetMapping.repo.ProductRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductRepository productRepository;

    public ProductController(ProductRepository productRepository){
        this.productRepository = productRepository;
    }

    @PostMapping
    public ResponseEntity<ProductDto> create(@RequestBody @Validated Product p){
        Product savedProduct = productRepository.save(p);
        return ResponseEntity.status(201).body(DtoMapper2.toDto(savedProduct));
    }

}
