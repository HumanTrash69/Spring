package com.example.HibernetMapping.repo;

import com.example.HibernetMapping.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {


}
