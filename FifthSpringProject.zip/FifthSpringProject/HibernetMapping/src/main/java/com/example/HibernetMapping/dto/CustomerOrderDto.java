package com.example.HibernetMapping.dto;

import jakarta.persistence.Column;

public record CustomerOrderDto(Long id, String orderNumber) {
}
