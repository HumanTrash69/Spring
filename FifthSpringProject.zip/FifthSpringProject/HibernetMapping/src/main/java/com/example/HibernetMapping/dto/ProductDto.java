package com.example.HibernetMapping.dto;

public record ProductDto( Long id, String name) {
}
