package com.example.HibernetMapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HibernetMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(HibernetMappingApplication.class, args);
	}

}
