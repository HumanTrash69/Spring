package com.example.HibernetMapping.dto;

public record ProfileDto (Long id, String fullName, String phone) {
}
