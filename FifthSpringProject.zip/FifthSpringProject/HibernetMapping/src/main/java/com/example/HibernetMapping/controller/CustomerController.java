package com.example.HibernetMapping.controller;

import com.example.HibernetMapping.dto.UserDto;
import com.example.HibernetMapping.mapper.DtoMapper;
import com.example.HibernetMapping.model.Customer;
import com.example.HibernetMapping.model.User;
import com.example.HibernetMapping.repo.CustomerRepository;
import com.example.HibernetMapping.repo.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   //    private final CustomerRepository customerRepository;
//
//    public CustomerController(CustomerRepository customerRepository){
//        this.customerRepository = customerRepository;
//    }
//

//    @PostMapping
//    public ResponseEntity<UserDto> create(@RequestBody @Validated UserDto dto){
//        Customer c = new Customer();
//        DtoMapper.UpdateEntityFromDto(c, dto);
//        User savedCustomer = customerRepository.save(c);
//        return ResponseEntity.status(201).body(DtoMapper.toDto(savedCustomer));
//    }
}
