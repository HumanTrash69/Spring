package com.example.HibernetMapping.dto;

import jakarta.persistence.Column;

public record AddressDto(String line1, String city, String state, String zip) {
}
