package com.example.SpringProject.mapper;

import com.example.SpringProject.dto.CourseResponse;
import com.example.SpringProject.dto.CreateCourseRequest;
import com.example.SpringProject.model.Course;

public class dtomapper {

    public static CourseResponse toResponse(Course c){
        CourseResponse cR = new CourseResponse();
        cR.setId(c.getId());
        cR.setCode(c.getCode());
        cR.setTitle(c.getTitle());
        cR.setDescription(c.getDescription());
        cR.setFee(c.getFee());
        cR.setActive(c.isActive());
        return cR;
    }

    public static Course fromCreate(CreateCourseRequest request){
        Course c = new Course();
        c.setCode(request.getCode());
        c.setTitle(request.getTitle());
        c.setDescription(request.getDescription());
        c.setFee(request.getFee());
        c.setActive(true);
        return c;
    }
}
