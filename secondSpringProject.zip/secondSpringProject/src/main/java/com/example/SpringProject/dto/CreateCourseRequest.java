package com.example.SpringProject.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CreateCourseRequest {
    private Long id;
    private String code;
    private String title;
    private String description;
    private BigDecimal fee;
    private boolean active;
    private LocalDateTime createdAt = LocalDateTime.now();
}
