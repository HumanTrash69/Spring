package com.example.SpringProject.controller;

import com.example.SpringProject.dto.CreateUserRepository;
import com.example.SpringProject.dto.UserResponse;
import com.example.SpringProject.exception.NotFoundException;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import com.example.SpringProject.services.UserServices;

import java.util.List;
@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserServices userServices;

    public UserController (UserServices userService){
        this.userServices = userService;

    }
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public UserResponse create(@Valid @RequestBody CreateUserRepository request){
        return userServices.create(request);
    }

    @GetMapping
    public List<UserResponse> getAll(){
        return userServices.getall();
    }

    @GetMapping("/{id}")
    public UserResponse getById(@PathVariable("id")Long id) throws NotFoundException{
        return userServices.getbyid(id);
    }

    @PutMapping("/{id}")
    public UserResponse update(@PathVariable("id")Long id,@RequestBody CreateUserRepository request) throws NotFoundException{
        return userServices.update(id,request);
    }

}
