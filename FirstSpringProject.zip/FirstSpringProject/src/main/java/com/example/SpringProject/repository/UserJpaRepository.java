package com.example.SpringProject.repository;

import com.example.SpringProject.domain.UserTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository

public interface UserJpaRepository extends JpaRepository<UserTable,Long > {

    Optional<UserTable> findByEmail(String email);

}
