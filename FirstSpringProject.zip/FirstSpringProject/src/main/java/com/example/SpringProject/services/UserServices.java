package com.example.SpringProject.services;

import com.example.SpringProject.domain.UserTable;
import com.example.SpringProject.dto.CreateUserRepository;
import com.example.SpringProject.dto.UserResponse;
import com.example.SpringProject.exception.NotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.SpringProject.repository.UserJpaRepository;

import java.util.List;
@Service
@Transactional
public class UserServices {
    private final UserJpaRepository userJpaRepository;
    public UserServices(UserJpaRepository userJpaRepository){
        this.userJpaRepository = userJpaRepository;

    }
    public UserResponse create(CreateUserRepository req) {

        UserTable user = new UserTable(req.getName(), req.getEmail(), req.getAge() );
        UserTable saveUser = userJpaRepository.save(user);
        return new UserResponse(saveUser.getId(), saveUser.getName(), saveUser.getEmail(), saveUser.getAge());


    }

    @Transactional(readOnly = true)

    public List<UserResponse> getall(){
        return userJpaRepository.findAll().stream().map(this::toresponse).toList();
    }

    public UserResponse toresponse(UserTable u){
        return new UserResponse(u.getId(), u.getName(), u.getEmail(), u.getAge());
    }

    @Transactional(readOnly = true)


    public UserResponse getbyid(Long id) throws NotFoundException {
        UserTable user = userJpaRepository.findById(id).orElseThrow(() -> new NotFoundException("user:"+ id + " Not found"));

        return toresponse(user);

    }


    @Transactional(readOnly = false)


    public UserResponse update(Long id, CreateUserRepository request) throws NotFoundException {
        UserTable existinguser = userJpaRepository.findById(id).orElseThrow(() -> new NotFoundException("user:"+ id + " Not found"));
        existinguser.setName(request.getName());
        existinguser.setAge(request.getAge());
        existinguser.setEmail(request.getEmail());
        UserTable saveduser=userJpaRepository.save(existinguser);
        return toresponse(saveduser);

    }


}
