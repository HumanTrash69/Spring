package com.example.SpringProject.domain;

import jakarta.persistence.*;

@Entity
@Table(name="user_table")
public class UserTable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private long id;
    private String name;
    private String email;
    private int age;

    public UserTable( String name, String email, int age) {

        this.name = name;
        this.email = email;
        this.age = age;
    }

    public UserTable() {

    }


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
